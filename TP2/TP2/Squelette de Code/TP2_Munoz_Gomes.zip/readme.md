Pour compiler le programme :
    - exécuter la commande : make

Pour lancer le programme :
    - exécuter la commande : ./tp2

Pour utiliser le programme : 
    - suivez les instructions données dans la console.